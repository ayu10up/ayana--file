// NAME : AYANA FILE DUGASA
// ID   : 2226/14
//SECTION : A


//importing necessary libraries
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class StudentRegistrationSystem {

    // JDBC URL, username, and password of MySQL server
    private static final String JDBC_URL = "jdbc:mysql://localhost:3306/university";
    private static final String USERNAME = "root";//my workbench name use your workbench name
    private static final String PASSWORD = "ayu10upmemysql";//my workbench password use your password

    // JDBC variables for opening, closing, and managing connection
    private static Connection connection;

    // Default password for viewing all students
    private static final String VIEW_ALL_PASSWORD = "0000";//this is registerer password to see registered student

    public static void main(String[] args) {
        try {
            // Connect to the database
            connection = DriverManager.getConnection(JDBC_URL, USERNAME, PASSWORD);

            // Create the students tables if they don't exist
            createFreshmanTable();
            createSeniorTable();

            // Create a new student registration system
            StudentRegistrationSystem registrationSystem = new StudentRegistrationSystem();

            // Show menu options
            registrationSystem.showMenu();

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            // Close the connection in the finally block to ensure it always happens
            try {
                if (connection != null && !connection.isClosed()) {
                    connection.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    // Method to create the freshman table if it doesn't exist
    private static void createFreshmanTable() {//create table for freshman student
        try {
            Statement statement = connection.createStatement();

            String createTableSQL = "CREATE TABLE IF NOT EXISTS freshmen (" +
                    "id INT AUTO_INCREMENT PRIMARY KEY," +
                    "stream VARCHAR(255) NOT NULL," +
                    "firstname VARCHAR(255) NOT NULL," +
                    "middlename VARCHAR(255) NOT NULL," +
                    "lastname VARCHAR(255) NOT NULL," +
                    "mothername VARCHAR(255) NOT NULL," +
                    "birthdate VARCHAR(23) NOT NULL," +
                    "uid VARCHAR(10) UNIQUE)";

            statement.executeUpdate(createTableSQL);

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Method to create the senior table if it doesn't exist
    private static void createSeniorTable() {
        try {
            Statement statement = connection.createStatement();
//              create table for senior students
            String createTableSQL = "CREATE TABLE IF NOT EXISTS seniors (" +
                    "id INT AUTO_INCREMENT PRIMARY KEY," +
                    "department VARCHAR(255)," +
                    "lastyeargpa DOUBLE)";

            statement.executeUpdate(createTableSQL);

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Method to display menu options
    private void showMenu() {

        try{

        while (true) {
            System.out.println(" **** WELL COME TO STUDENT REGISTRATION SYSTEM ****");
            System.out.println("1. Register");
            System.out.println("2. View registered students");
            System.out.println("3. Exit");

            System.out.print("Enter your choice: ");
            Scanner scanner = new Scanner(System.in);
            int choice = scanner.nextInt();

                switch (choice) {
                    case 1:
                        registerStudent();
                        break;
                    case 2:
                        viewAllStudents();
                        break;
                    case 3:
                        System.out.println("Exiting the program. Goodbye!");
                        return;
                    default:
                        System.out.println("Invalid choice. Please enter a valid option.");
                }
            }


        }
        catch (Exception e){
            System.out.println();
            System.out.println("\uD83D\uDC49\uD83C\uDFFE invalid datatype please inter int datatype for this choice");
            showMenu();
        }
    }

    // Method to register a new student
    private void registerStudent() {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter student details:");

       try{ System.out.print("Freshman (1) or Senior (2): ");
        int studentType = scanner.nextInt();

        if (studentType == 1) {
            // Freshman
            registerFreshman();
        } else if (studentType == 2) {
            // Senior
            registerSenior();
        } else {
            System.out.println("Invalid input. Please enter 1 for Freshman or 2 for Senior.");
        }}
       catch (Exception e){
           System.out.println();
           System.out.println(" \uD83D\uDC49\uD83C\uDFFE invalid datatype please insert Int data type for Enter student details");
           registerStudent();
       }
    }

    // Method to register a freshman
    private void registerFreshman() {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter stream (Natural Science or Social Science): ");
        String stream = scanner.nextLine();

        System.out.print("Enter first name: ");
        String firstName = scanner.nextLine();

        System.out.print("Enter middle name: ");
        String middleName = scanner.nextLine();

        System.out.print("Enter last name: ");
        String lastName = scanner.nextLine();

        System.out.print("Enter mother's name: ");
        String motherName = scanner.nextLine();

        System.out.print("Enter date of birth (YYYY-MM-DD): ");
        String birthDate = scanner.nextLine();

        System.out.print("Enter UID: ");
        String uid = scanner.next();

        try {
            // Insert the new freshman into the freshmen table
            String sql = "INSERT INTO freshmen (stream, firstname, middlename, lastname, mothername, birthdate, uid) " +
                    "VALUES (?, ?, ?, ?, ?, ?, ?)";
            try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
                preparedStatement.setString(1, stream);
                preparedStatement.setString(2, firstName);
                preparedStatement.setString(3, middleName);
                preparedStatement.setString(4, lastName);
                preparedStatement.setString(5, motherName);
                preparedStatement.setString(6, birthDate);
                preparedStatement.setString(7, uid);
                int rowsAffected = preparedStatement.executeUpdate();

                if (rowsAffected > 0) {
                    System.out.println("Freshman registered successfully!");
                } else {
                    System.out.println("Failed to register the freshman. Please try again.");
                }
                System.out.println();

            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Method to register a senior
    private void registerSenior() {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter student ID: ");
        int id = scanner.nextInt();

        System.out.print("Enter department: ");
        String department = scanner.next();

        System.out.print("Enter last year's cumulative GPA: ");
        double lastYearGPA = scanner.nextDouble();

        if (lastYearGPA > 0 && lastYearGPA < 1.75) {
            System.out.println("Sorry, you are disqualified.");
        } else if (lastYearGPA >= 1.75 && lastYearGPA <= 4.0) {
            try {
                // Insert the new senior into the seniors table
                String sql = "INSERT INTO seniors (id, department, lastyeargpa) VALUES (?, ?, ?)";
                try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
                    preparedStatement.setInt(1, id);
                    preparedStatement.setString(2, department);
                    preparedStatement.setDouble(3, lastYearGPA);
                    int rowsAffected = preparedStatement.executeUpdate();

                    if (rowsAffected > 0) {
                        System.out.println("Senior registered successfully!");
                    } else {
                        System.out.println("Failed to register the senior. Please try again.");
                    }
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        } else {
            System.out.println("Invalid input. Please enter a GPA between 0 and 4.");
        }
    }

    // Method to view all students
    private void viewAllStudents() {
        Scanner scanner = new Scanner(System.in);

        // Ask for password to view all students
        System.out.println("-----Only registerer can see the registered students -----");
        System.out.println("Enter password to verify you are registerer: ");
        String passwordAttempt = scanner.next();

        if (passwordAttempt.equals(VIEW_ALL_PASSWORD)) {
            try {
                // Retrieve all freshmen from the freshmen table
                String freshmanSql = "SELECT * FROM freshmen";
                try (PreparedStatement preparedStatement = connection.prepareStatement(freshmanSql);
                     ResultSet resultSet = preparedStatement.executeQuery()) {

                    System.out.println("List of all freshmen:");

                    while (resultSet.next()) {
                        int id = resultSet.getInt("id");
                        String stream = resultSet.getString("stream");
                        String firstName = resultSet.getString("firstname");
                        String middleName = resultSet.getString("middlename");
                        String lastName = resultSet.getString("lastname");
                        String motherName = resultSet.getString("mothername");
                        String birthDate = resultSet.getString("birthdate");
                        String uid = resultSet.getString("uid");

                        System.out.println("ID: " + id + ", Stream: " + stream +
                                ", First Name: " + firstName + ", Middle Name: " + middleName +
                                ", Last Name: " + lastName + ", Mother's Name: " + motherName +
                                ", Birth Date: " + birthDate + ", UID: " + uid);
                    }
                }

                // Retrieve all seniors from the seniors table
                String seniorSql = "SELECT * FROM seniors";
                try (PreparedStatement preparedStatement = connection.prepareStatement(seniorSql);
                     ResultSet resultSet = preparedStatement.executeQuery()) {

                    System.out.println("List of all seniors:");

                    while (resultSet.next()) {
                        int id = resultSet.getInt("id");
                        String department = resultSet.getString("department");
                        double lastYearGPA = resultSet.getDouble("lastyeargpa");

                        System.out.println("ID: " + id + ", Department: " + department +
                                ", Last Year GPA: " + lastYearGPA);
                    }
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        } else {
            System.out.println("Invalid password. Please insert the correct password.");
        }
    }
}