// NAME : AYANA FILE DUGASA
// ID   : 2226/14
//SECTION : A
class Address extends Person {
    protected String nationality;
    protected String country;
    protected String region;
    protected String zone;
    protected String kebele;

    public Address(String firstName, String middleName, String lastName, int age,
                   String nationality, String country, String region, String zone, String kebele) {
        super(firstName, middleName, lastName, age);
        this.nationality = nationality;
        this.country = country;
        this.region = region;
        this.zone = zone;
        this.kebele = kebele;
    }

    public String getNationality() {
        return nationality;
    }

    public String getCountry() {
        return country;
    }

    public String getRegion() {
        return region;
    }

    public String getZone() {
        return zone;
    }

    public String getKebele() {
        return kebele;
    }
}
